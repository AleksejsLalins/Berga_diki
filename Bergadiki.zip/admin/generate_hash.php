<?php
echo password_hash('Rihards2023@', PASSWORD_BCRYPT);
?>
