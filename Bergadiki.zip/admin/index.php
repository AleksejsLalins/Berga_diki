<?php
header("Location: edit.php");
exit;
?>
