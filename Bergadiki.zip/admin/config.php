<?php
// =============================
// 🛠️ Настройки логирования ошибок
// =============================
ini_set('display_errors', 1);                  // Показывать ошибки на экране (можно отключить в продакшне)
ini_set('display_startup_errors', 1);          // Показывать стартовые ошибки
ini_set('log_errors', 1);                      // Включить логирование
ini_set('error_log', __DIR__ . '/../logs/php_errors.log');  // Путь к лог-файлу вне веб-доступа
error_reporting(E_ALL);                        // Уровень ошибок


// Настройки базы данных
define('DB_HOST', 'localhost'); // Это обычно localhost, если не так - уточните у хостинга
define('DB_USER', 'yachtwor_Rihards'); // Имя пользователя, которое вы создали
define('DB_PASSWORD', 'Rihards2023@'); // Пароль для пользователя
define('DB_NAME', 'yachtwor_berga'); // Имя базы данных

// Пытаемся начать сессию только если она еще не активна
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Установка языка по умолчанию, если он еще не установлен в сессии
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'lv';  // Установим язык по умолчанию
}

// Если передан параметр языка, меняем его
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

// Функция для подключения к базе данных
function getDBConnection() {
    try {
        // Устанавливаем кодировку UTF-8 при подключении к базе данных
        $options = [
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ];

        return new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASSWORD,
            $options
        );
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}
?>
