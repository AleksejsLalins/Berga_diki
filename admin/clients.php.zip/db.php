<?php
$host = 'localhost'; // Или ваш сервер базы данных
$dbname = 'yachtwor_berga';
$username = 'yachtwor_Rihards';
$password = 'Rihards2023@';

// Подключение к базе данных
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Ошибка подключения: ' . $e->getMessage();
    exit;
}

// Получаем язык из GET-параметра (по умолчанию 'lv', если не указан)
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'lv'; // 'lv' - по умолчанию, если не указан

// Извлекаем данные для выбранного языка
$query = "SELECT * FROM sections WHERE language = :lang";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':lang', $lang, PDO::PARAM_STR);
$stmt->execute();
$sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Проверяем, если данные не найдены
if (empty($sections)) {
    echo json_encode(["error" => "Секции не найдены для языка: $lang"]);
    exit;
}

// Отдаём данные в формате JSON
header('Content-Type: application/json');
echo json_encode($sections);
?>
